from Auxiliares import *
def ParesPD(num):
    if type(num)==int:
        num=abs(num)
        listaNueva=Pasalista(num)
        if listaNueva==[0]:
            return [0]
        else:
            return ParesPD_aux(listaNueva)
    else:
        print('Parametro incorrecto')
        
def ParesPD_aux(lista):
    if lista==[]:
        return []
    if lista[0]%2==0:
        return [lista[0]]+ ParesPD_aux(lista[1:])
    else:
        return ParesPD_aux(lista[1:])
#print(ParesPD(8121325))