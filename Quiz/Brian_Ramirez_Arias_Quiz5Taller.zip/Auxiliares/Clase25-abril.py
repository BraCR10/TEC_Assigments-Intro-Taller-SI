import Auxiliares
def ParesCD(num):
    if type(num)==int:
        num=abs(num)
        listaNueva=Auxiliares.Pasalista(num)
        if listaNueva==[0]:
            return [0]
        else:
            return ParesCD_aux(listaNueva,[])
    else:
        print('Parametro incorrecto')
        
def ParesCD_aux(lista,listaFinal):
    if lista==[]:
        return listaFinal
    if lista[0]%2==0:
        return ParesCD_aux(lista[1:],listaFinal+[lista[0]])
    else:
        return ParesCD_aux(lista[1:],listaFinal)
#print(ParesCD(81225))