from Auxiliares import Pasalista
def ParesCSD(num):
    if type(num)==int:
        num=abs(num)
        listaNueva=Pasalista(num)
        if listaNueva==[0]:
            return [0]
        else:
            return ParesCSD_aux(listaNueva,[],0)
    else:
        print('Parametro incorrecto')
        
def ParesCSD_aux(lista,listaFinal,i):
    if i==len(lista):
        return listaFinal
    if lista[i]%2==0:
        return ParesCSD_aux(lista,listaFinal+[lista[i]],i+1)
    else:
        return ParesCSD_aux(lista,listaFinal,i+1)
#print(ParesCSD(81225))

